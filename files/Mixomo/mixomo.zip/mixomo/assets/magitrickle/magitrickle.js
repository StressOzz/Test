'use strict';
'require view';

return view.extend({
    handleSave: null,
    handleSaveApply: null,
    handleReset: null,

    render: function() {
        var hostname = window.location.hostname;
        var port = '8080';
        var url = 'http://' + hostname + ':' + port;

        if (window.location.protocol === 'https:') {
            return E('div', { style: 'padding: 20px; text-align: center;' }, [
                E('p', _('HTTPS соединение блокирует встроенный интерфейс MagiTrickle через LuCI.')),
                E('p', { style: 'margin-bottom: 20px;' }, _('Пожалуйста, откройте MagiTrickle в новой вкладке для полноценного управления.')),
                E('a', {
                    'class': 'btn cbi-button-action',
                    'href': url,
                    'target': '_blank',
                    'style': 'padding: 10px 20px; font-size: 1.1em;'
                }, _('Открыть MagiTrickle'))
            ]);
        }

        return E('div', {
            style: 'width:100%; height:92vh; margin: -20px -20px 0 -20px; overflow: hidden;'
        }, E('iframe', {
            src: url,
            style: 'width:100%; height:100%; border: none;'
        }));
    }
});
